/* gen_ai_plan.js — 生成《学情预警系统 v2.0 · 第三阶段 AI 智能规划（修订稿 · Dify 自托管）》
 * 用法: node gen_ai_plan.js
 * 本版变化（按用户要求）：
 *   1) 取消"知识点"相关设计（不新建本体、不改表、不做映射），归因改用已有的成绩构成项 / 试卷 / 题型 / 课时维度；
 *   2) Agent 明确推荐 Dify 自托管，弃用 Spring AI 主线；
 *   3) 全篇围绕"本地 Docker 部署且不与现有栈冲突"给出端口、compose、镜像与备份方案。
 */
'use strict';
const fs = require('fs');
const path = require('path');

const B = [];
const h1 = (x) => B.push({ t: 'h1', x });
const h2 = (x) => B.push({ t: 'h2', x });
const h3 = (x) => B.push({ t: 'h3', x });
const p = (x) => B.push({ t: 'p', x });
const note = (x) => B.push({ t: 'note', x });
const ul = (x) => B.push({ t: 'ul', x });
const ol = (x) => B.push({ t: 'ol', x });
const table = (cap, head, rows, widths) => B.push({ t: 'table', cap, head, rows, widths });

/* ==================== 1 修订说明与定位 ==================== */
h1('1 修订说明与第三阶段定位');
h2('1.1 本版改了什么');
table('相对上一版的三处调整',
  ['上一版的做法', '本版的做法', '原因'],
  [
    ['把"知识点"当作第三阶段地基：先补 150 个叶子节点，再把 274 道题挂上去', '**完全不引入知识点**：不建表、不加字段、不做映射；归因改用系统里已有的"成绩构成项 / 试卷 / 题型 / 课时"四个维度', '知识点属于教学本体建模，写好要教材级投入；现有外键已经能回答"哪一块低"，再加一层只增加维护成本'],
    ['Agent 主线用 Spring AI 2.0.2 在 Java 里写编排', '**主线改为 Dify 自托管（本地 Docker）**：出题 / 报告 / 问答三条可视化工作流，Spring Boot 只做业务网关与治理', '工作流可视化、RAG 与引用开箱即用、提示词改完即时生效；代码写编排迭代太慢'],
    ['部署只说"装 Dify"，没算端口与资源', '给出**端口 / 容器 / 卷的规划表 + compose 覆盖片段 + 离线镜像清单**，并实测本机 Docker 与端口占用', '最终要落到本地 Docker，冲突与资源最容易在演示前夜翻车']
  ], [26, 40, 34]);
h2('1.2 第三阶段要解决的两件事');
ol([
  '**老师少出题、少批改**：把课堂 PPT / 课件变成题目草稿，老师只审与改；主观题批改给"分数建议 + 评语草稿"。',
  '**学生知道差在哪**：把已有的分数、作答、考勤、项目、预警汇成一份看得懂的报告，指出"哪一块低、下一步做什么"。'
]);
h2('1.3 四条不可让步的原则');
ul([
  '**数字不由模型生成**：报告里每个分数、次数、百分比都由 SQL/Java 算好后注入，生成后做一次数字回验，不一致就退回模板。',
  '**产物一律草稿**：AI 出的题、AI 写的报告都进草稿表，状态从 DRAFT 到 APPROVED 或 REJECTED，人工确认才对外可见。',
  '**AI 可下线**：`ai.enabled=false` 时后端不再调用 Dify，所有入口回退到规则/模板结果，页面不报错。',
  '**权威数据只在 MySQL**：Dify 只负责生成与检索，题库、成绩、预警的真相永远在 v2.0 的库里。'
]);

/* ==================== 2 现状盘点 ==================== */
h1('2 现状盘点：不加知识点，靠什么做归因');
h2('2.1 已有数据（当前演示库实测）');
table('第二阶段留下的数据资产',
  ['数据', '规模（实测）', '可直接当什么维度用'],
  [
    ['课程 / 教学班 / 选课', '5 门课 / 12 个教学班 / 540 条选课', '权限边界（按班、按课隔离）'],
    ['课时', '164 次课；每班一套 lesson（含周次）', '**时间维度**：第几周、第几次课'],
    ['试卷', '127 份（QUIZ 81 / HOMEWORK 46），带 lesson_id', '**场景维度**：测验 / 作业 / 属于哪次课'],
    ['题目', '274 道（SHORT 259、SINGLE 6、MULTI 3、JUDGE 3、BLANK 3），带 group_name', '**题型维度 + 分组维度**（group_name 是老师自己写的小标题）'],
    ['作答明细', '5580 份提交、11160 条作答（含 is_correct 与得分）', '**正确率原料**：按试卷 / 题型 / 分组聚合'],
    ['成绩构成', '两级构成 + 810 条手工成绩 + 自动汇总（试卷、项目）', '**分项维度**：测试 / 作业 / 项目 / 表现 / 期中 / 期末'],
    ['项目', '13 个任务、81 支队伍、306 份提交、81 条贡献度', '**协作维度**'],
    ['考勤', '15255 条记录（含历史学期）', '**投入维度**'],
    ['预警', '540 条结论（绿 504 / 黄 20 / 红 16）、36 条事件', '**结论维度**：报告第一段直接引用'],
    ['问卷', '5 份、25 条作答', '非学业信号（样本太少，只提示不下结论）'],
    ['教学资料', '3 个资源（txt）、12 份导学', 'RAG 与出题语料（**格式单一，需补 PPTX**）']
  ], [20, 38, 42]);
h2('2.2 关键论证：不加知识点，归因也够用');
p('上一版把知识点当必需，是因为默认了"只有知识点才能定位薄弱"。实际上从作答明细走到"哪一块低"，**现有的三跳外键就能走通，一行新表都不用加**：');
p('作答明细 → 题目 → 试卷 → 课时 / 试卷类型，同时题上的 group_name 与 q_type 就在同一行。于是有四个可直接落地的维度：');
table('四个维度的算法与用法',
  ['维度', '怎么算', '报告里怎么说'],
  [
    ['分项（成绩构成）', '每个子项得分 ÷ 满分，与班级均值比；失分贡献度 = 子项失分 ÷ 总失分', '你 62 分里测试项只有 48 分，占你失分的 41%；作业项 78 分是强项'],
    ['试卷 / 课时', '按 paper 聚合得分率，按 lesson.week_no 排成时间序列', '第 6 到 9 周的测验得分率从 71% 掉到 52%，正好是缺勤集中的两周'],
    ['分组（group_name）', '同一 group_name 的题合起来算正确率（老师写的小标题天然就是章节）', '「链表操作」这组 5 题你对了 2 题，是全卷最低的一组'],
    ['题型', '按 q_type 算正确率与平均分', '单选 83%、判断 90%，但简答平均只有 41% —— 你不是不会，是写不出'],
    ['投入 / 协作 / 结论', '考勤、项目贡献度、risk_state 直接拼装', '缺勤 5 次（允许 4 次）、项目贡献比 1.1、当前红灯']
  ], [20, 42, 38]);
note('这套方案最大的好处是**零迁移成本**：知识点方案要新增 2 张表、改 1 张已有表、再给 274 道题做人工挂接；本方案不改任何 SQL 结构，出题与报告都能在现有数据上直接跑。');
p('唯一的取舍：group_name 是老师自定义的小标题，命名不统一（"链表"和"链表操作"会分开统计）。治理办法不是建本体，而是**出题时把该课已出现的分组名作为候选传给模型**，让新题沿用词表，命名会自然收敛。');
h2('2.3 v1.0 的 AI 资产：换底座后还剩什么');
p('v1.0 后端手写了一套完整 Agent 骨架。改成 Dify 之后，**编排层交出去，治理层留下来**：');
table('v1.0 资产处置（Dify 版）',
  ['资产（v1.0）', '作用', '处置', '理由'],
  [
    ['AgentRunContext / AgentEvent', '运行上下文 + 进度事件', '**保留**', '异步任务中心与"生成中"状态的底座'],
    ['AgentOutputValidator', '结构 / 取值 / 真值一致性校验', '**保留并强化**', 'Dify 输出后仍要在 Java 侧过一遍，这是防幻觉最可靠的一层'],
    ['ReflectionLoop（带批评重写）', 'Self-Refine', '**保留但简化**', 'Dify 侧用代码节点校验加一次重试，Java 侧只做最终闸门'],
    ['AgentOrchestrator / 6 个域 Agent', '三段流水线编排', '**退役**', '编排搬到 Dify 工作流；归因算法留在 Java'],
    ['ToolCallingLoop / ToolRegistry / AgentTool', '手写工具循环', '**退役**', 'Dify 的 Agent / 工具节点 + HTTP 请求节点替代'],
    ['9 个工具（ScoreInfo / RiskProfile / RiskTrend / WeakPoint / AlertList / StudentCourses / Profile3D / Memory）', '把学情数据变成可调用函数', '**保留语义，改造成 `/api/ai/tools/*` 供 Dify 调用**', '让 Dify 不直连数据库，权限、审计、脱敏都在 Java 侧'],
    ['BailianChatClient / BailianRAGClient', '手写 HTTP 调用 + 引用提取 + 拒答', '**退役**', '模型通道由 Dify 统一管理；引用与拒答在 Dify 知识库配置'],
    ['KnowledgeBaseBuilder', '从库里结构化数据生成知识文本', '**保留**', '正是"先抽文本再喂知识库"的思路，换成"课件 → markdown → 上传"'],
    ['AgentEvalService + golden 集', '离线评测', '**保留并扩**', '第三阶段能否说清"AI 准不准"全靠它'],
    ['agent_run / agent_run_step 落库', '运行与步级明细', '**保留**（改名 `ai_run` / `ai_run_step`）', '审计与成本核算，也是答辩时"可追溯"的物证'],
    ['前端 6 个 AI 组件', '对话 / 运行历史 / 工具问答 / 知识面板', '**改造复用**', '交互骨架可用，样式与状态按 v2.0 规范重做']
  ], [26, 22, 22, 30]);
h2('2.4 环境与通道实测');
table('本机与外部服务的实测结果',
  ['验证项', '方法', '结果'],
  [
    ['Docker 是否可用', '`docker --version` / `docker compose version`', '**已装**：Docker 28.5.1、Compose v2.40.0-desktop'],
    ['本机内存', '系统信息', '**15.7 GiB**（够跑 Dify 全家桶，建议给 Docker Desktop 8 GiB）'],
    ['现有端口占用', '监听端口扫描', 'MySQL **3306** 占用；**80 / 443 / 8080 / 5173 均空闲**'],
    ['DashScope Key 是否过期', '调 `compatible-mode/v1/chat/completions`（qwen-plus）', '**有效**，正常返回 200'],
    ['v1.0 的百炼应用是否还在', '调 `/api/v1/apps/{appId}/completion`（3 个）', '**都在**，均 200；知识库内容属 v1.0 两门课，v2.0 需重建'],
    ['Dify 是否原生解析 PPTX', '查 Dify 源码 `api/constants/__init__.py`', '**默认不支持**：`pptx` 只在 `ETL_TYPE=Unstructured` 分支内；默认集为 txt / md / pdf / html / xlsx / xls / docx / csv / vtt / odt'],
    ['Dify 当前版本线', 'Docker Hub 镜像 tag', '**1.18.x**（可见 hotfix-1.18.0-fix.1），部署时固定 tag，不要用 main'],
    ['Dify 官方硬件门槛', '官方部署文档', 'CPU ≥2 核、RAM ≥4 GiB；Windows + WSL2 建议给 Docker VM ≥8 GiB'],
    ['Dify 默认占用哪些宿主端口', '读官方 `docker/docker-compose.yaml`', '**只有 nginx（80 / 443）与 plugin_daemon（5003）**；db / redis / weaviate / sandbox 均不发布宿主端口，weaviate 现挂在 `weaviate` profile 下']
  ], [26, 34, 40]);
note('这条实测结论很关键：**Dify 默认不抢 8080 与 3306**（原先担心的 weaviate 8080 在现版本并不发布到宿主）。真正要改的只有 nginx 的 80 / 443 —— 挪到 8090 / 8443 就与现有栈零冲突。');

/* ==================== 3 AI 出题 ==================== */
h1('3 能力一：AI 出题（课件 → 题目草稿 → 审题 → 入卷）');
h2('3.1 教师侧用户路径');
ol([
  '教师进入「我的教学 → 某个班 → 课件 / 资料」，勾选本节课的 PPT 或资料（可多选）。',
  '点「AI 出题」：选题型、数量、难度、分值，并指定**小节范围**（按 PPT 页码或课件标题层级，而不是知识点）。',
  '系统异步生成，题干逐题返回；教师可**单题重生成、删除、编辑**。',
  '确认后「加入试卷」：新建 DRAFT 试卷，或追加到已有试卷的某个分组（复用 `question.group_name`）。',
  '试卷照旧走发布流程 —— AI 只把"出题"从 20 分钟压到 2 分钟，其他环节一个都不绕过。'
]);
h2('3.2 课件怎么进 Dify（决定成败的一步）');
p('Dify 默认 ETL 不认 PPTX（见 2.4 实测），而"打开 Unstructured 服务"会多一个容器、且对中文 PPT 版面解析不稳定。**推荐做法：后端先抽文本，再以 markdown 上传**。');
table('课件处理链路',
  ['步骤', '做什么', '实现在哪', '为什么这么做'],
  [
    ['① 抽文本', 'PPTX / DOCX 逐页抽文字，保留"第 N 页 / 标题层级"', '**Spring Boot**（已依赖 `poi-ooxml 5.2.5`，零新增依赖）', '不依赖 Dify 的 ETL 能力，抽取质量自己可控'],
    ['② 生成 markdown', '整理成"## 第 N 页 · 标题"加正文的分块文本', 'Spring Boot', 'Dify 按 markdown 标题切块，天然带页码，引用能追到页'],
    ['③ 上传知识库', '调 Dify `POST /v1/datasets/{id}/document/create-by-text`', 'Spring Boot 代理 → Dify API', '知识库内容与 `resource_file` 一一对应，可重复导入 / 删除'],
    ['④ 出题取上下文', 'Dify 工作流里"知识检索"节点召回片段，喂给出题 LLM', 'Dify 工作流', '生成题能回指片段，审题页展示"依据：第 12 页"'],
    ['⑤ 回收结果', '工作流输出 JSON → Spring 校验 → 落 `ai_question_draft`', 'Spring Boot', '校验、脱敏、审计都在自己手里']
  ], [14, 28, 26, 32]);
note('若坚持让 Dify 自己解析 PPTX：`.env` 设 `ETL_TYPE=Unstructured` 并起 `unstructured` profile，代价是多一个容器、镜像更大、中文版面识别不稳。**不建议作为主线**，可留作"教师直接拖 PPT 试试"的辅助通道。');
h2('3.3 Dify 工作流设计（出题）');
table('出题工作流的节点清单',
  ['节点', '类型', '输入 → 输出', '要点'],
  [
    ['开始', 'start', 'offeringId / lessonId / resourceIds / 题型 / 数量 / 难度 / 小节范围', '由 Spring 传入，均为结构化字段'],
    ['取上下文', '知识检索', '查询串 → TopK 片段（含 page 元数据）', '按 dataset（课程级）过滤，只在本课资料里检索'],
    ['拟大纲', 'LLM', '片段 → "本节可考 6 个点"', '先锁定可考点避免跑题，这一步用小模型，便宜'],
    ['出题', 'LLM', '大纲 + 片段 → 题目 JSON 数组', '严格 JSON、按给定 Schema、温度 0.3'],
    ['机检', '代码节点', 'JSON → 通过 / 不通过 + 错误清单', '结构、选项数、答案闭合、题干长度、指代词黑名单'],
    ['去重', '代码节点', '题干指纹 + 相似度 → 重复标记', '与该课已有题目比对，相似度 > 0.92 判重'],
    ['重试', '条件分支', '不通过 → 带错误信息重跑"出题"', '最多 1 次；仍失败则如实返回失败原因，不硬塞'],
    ['输出', 'end', '题目数组 + 依据页 + 用量', 'Spring 落库、计费、写 `ai_run_step`']
  ], [12, 18, 38, 32]);
h2('3.4 五道质量闸门（Dify 代码节点 + Spring 各把一道）');
ul([
  '**结构闸门**：题型枚举合法、单选选项 ≥2、正确答案必须在选项集合内、分值 > 0；JSON 解析失败直接重试。',
  '**答案闭合闸门**：单选恰好 1 个答案；多选 2 到 4 个；判断只能是 T 或 F；填空答案集合非空。',
  '**题干可读闸门**：题干 10 到 300 字，不含"根据材料""上述内容"这类指代词，不含 Markdown 标记与页码残留。',
  '**重复闸门**：归一化后精确去重；再用 embedding 相似度 > 0.92 判重（同一份 PPT 反复出同一题是常见退化）。',
  '**覆盖闸门**：一份卷子覆盖指定小节范围 ≥ 60%（用片段的 page 元数据统计），避免"全考第一页"。'
]);
h2('3.5 数据模型（不含知识点）');
table('出题相关表',
  ['表名', '用途', '关键字段'],
  [
    ['`ai_question_draft`', 'AI 出题草稿与审核', 'id, offering_id, lesson_id, resource_ids, q_type, difficulty, stem, options_json, answer_json, analysis, group_name, source_pages, quality_json, status, model, prompt_version, tokens, cost, create_by, reviewer_id, review_time, deleted'],
    ['`ai_run`', '一次 AI 任务的运行', 'id, scene, target_type, target_id, status, model, app_id, prompt_version, total_tokens, total_cost, operator_id, create_time, finish_time'],
    ['`ai_run_step`', '步级明细', 'id, run_id, step_no, name, input_digest, output_digest, validation_status, validation_detail, duration_ms, error'],
    ['`ai_usage`', '计费与限流', 'id, run_id, scene, model, prompt_tokens, completion_tokens, cost, operator_id, create_time'],
    ['`ai_prompt_template`', '提示词与工作流版本对应', 'id, code, version, dify_app_id, workflow_version, note, status, create_time'],
    ['`resource_chunk`（可选）', '课件分块与 embedding 缓存', 'id, resource_id, page_no, text, char_len, embedding, model, create_time']
  ], [24, 30, 46]);
note('`question.paper_id` 是 NOT NULL，所以 AI 草稿不进 `question`；采纳时才插入并绑定试卷。**不改任何老表结构** —— 这正是"不加知识点"带来的直接收益。');
h2('3.6 验收指标');
table('AI 出题验收',
  ['指标', '目标值', '怎么测'],
  [
    ['生成可用率', '≥ 80%（通过五道闸门）', '抽 20 份课件，每份 5 题，统计通过数'],
    ['人工修改率', '≤ 40%', '审题页"改后通过 / 通过"比例'],
    ['结构不合规率', '≤ 5%', '重试 1 次后的失败率'],
    ['单次生成耗时', '5 题 ≤ 30 秒（异步 + 逐题返回）', '`ai_run_step.duration_ms`'],
    ['单题成本', '≤ 0.01 元', '`ai_usage.cost / 题数`'],
    ['小节覆盖', '≥ 60% 指定范围', '`source_pages` 去重计数'],
    ['重复率', '≤ 5%', '相似度 > 0.92 的题对占比']
  ], [22, 30, 48]);
h2('3.7 风险与对策');
ul([
  '**图片型 PPT**：抽到的文本长度为 0 或每页少于 30 字时判定"图片版课件"，提示"改用可复制文本的课件或粘贴文本"，不承诺 OCR。',
  '**公式与代码**：第一版明确不支持公式题；代码题只做"读程序写结果"，且要求代码在 PPT 里是文本块。',
  '**版权**：只能对本课程组已上传的资料出题，生成物归课程组，不外发、不整本教材灌库。',
  '**教师不信任**：审题页每题下方贴"依据：第 12 页 + 原文片段"，这比任何准确率数字都管用。'
]);

/* ==================== 4 学习评价报告 ==================== */
h1('4 能力二：AI 学习评价报告（学生端）');
h2('4.1 三种形态');
table('报告形态',
  ['形态', '触发', '长度', '重心'],
  [
    ['阶段报告', '每 4 周或章节结束时批量生成', '600 到 900 字', '这一阶段学得怎么样、哪一块低、下阶段做什么'],
    ['预警简报', '预警创建 / 升级时随事件生成', '200 到 300 字', '为什么给你发这条预警、缺什么、怎么补'],
    ['追问', '学生在报告页追问一句', '150 到 300 字', '基于本报告上下文加课程知识库作答']
  ], [14, 32, 14, 40]);
h2('4.2 输入：FactPack（只读事实，模型不改）');
table('FactPack 字段（以计基 01 班某学生为例）',
  ['分组', '字段', '来源（全是已有表）'],
  [
    ['课程', '课程名、学分、周次、考核方式、成绩构成百分比', 'course / course_offering / score_scheme'],
    ['总分', '当前总分、班级均分、班内位次', 'score_result 聚合'],
    ['分项', '各子项得分与满分、与班级均值差、失分贡献 Top3', 'score_scheme_item + 自动汇总'],
    ['试卷', '每次测验 / 作业的得分率、按周次的时间序列', 'paper + submission'],
    ['分组', 'group_name 维度正确率，最低的 3 组', 'question.group_name + submission_answer'],
    ['题型', '按 q_type 的正确率与平均分', 'question.q_type + submission_answer'],
    ['投入', '出勤、缺勤、迟到、请假、作业提交率（应交 / 实交）', 'attendance_record / submission'],
    ['协作', '项目团队分、个人贡献比、个人折算分', 'project_team / project_contribution'],
    ['结论', '当前预警等级、触发原因、距下一档差多少分', 'risk_state + alert_record'],
    ['非学业', '心理健康问卷是否提示"建议关注"（不出结论）', 'questionnaire_answer']
  ], [12, 46, 42]);
h2('4.3 归因算法：三个排序，全部可复算');
ol([
  '**分项失分贡献度**：对每个成绩构成子项算（满分 − 得分）÷ 满分，再除以总失分，取 Top3。',
  '**分组正确率**：按 `question.group_name` 聚合 `submission_answer` 的 is_correct（简答题按得分率），与班级均值比较，取低于均值最多的 3 组。',
  '**时间趋势**：按 `lesson.week_no` 排试卷得分率，做一次线性拟合，斜率显著为负就点名"从第 N 周开始下降"。'
]);
p('模型只做一件事：把这三个排序翻译成学生能读懂的"事实 → 影响 → 动作"。示例（规则算出的数字）：');
p('「链表操作」这组 5 题对了 2 题（得分率 40%，班级均值 74%），是失分最多的一组，占总失分 32%。模型输出 —— "你在「链表操作」上丢分最多：这组题 5 道你对了 2 道，班里平均对 4 道。看起来是插入和删除的位置关系没理顺。下一步：把第 6 周测验的那 3 道链表题重做一遍，再来看看这周的小测。"');
h2('4.4 防幻觉三道锁');
ul([
  '**数字白名单**：Prompt 里只允许出现 FactPack 中的数字；生成后用正则抽出所有数字逐个比对，出现白名单外的数字即判失败。',
  '**结论不越权**：禁止输出"你会挂科""肯定过不了"，判定结论只能引用 `risk_state` 的等级文案。',
  '**模板兜底**：模型不可用 / 超时 / 校验失败时，直接输出第二阶段的规则建议（每个分项、每个分组都有模板句），报告照常生成，只是少了"人话"。'
]);
h2('4.5 Dify 工作流设计（报告）');
table('报告工作流节点',
  ['节点', '类型', '说明'],
  [
    ['开始', 'start', 'FactPack（JSON 字符串）+ 报告类型 + 字数上限'],
    ['事实摘要', '代码节点', '把 FactPack 压成"必讲的 6 条事实"，减少 token 与跑题'],
    ['写作', 'LLM', '输出固定四段：结论 / 强项 / 待补 / 下阶段动作'],
    ['数字回验', '代码节点', '抽出文中数字与 FactPack 比对，输出不符清单'],
    ['修复 / 降级', '条件分支', '不符则带不符项重写一次；仍不符走模板'],
    ['输出', 'end', '正文 + 三个动作（动作由规则给，不由模型编）'],
    ['动作落地', 'Spring', '存 `ai_report`；动作映射为页面按钮（重做这几题 / 看这章导学 / 约答疑）']
  ], [14, 16, 70]);
h2('4.6 表与接口');
table('报告相关表与接口',
  ['对象', '说明'],
  [
    ['`ai_report`', 'id, student_id, course_id, enrollment_id, term_id, report_type, period_start, period_end, fact_json, content_json, status, model, app_id, prompt_version, tokens, cost, publish_time'],
    ['`ai_report_feedback`', 'id, report_id, student_id, useful, reason, create_time'],
    ['`GET /api/student/reports` 与 `/{id}`', '学生端列表与详情（只能看自己的）'],
    ['`POST /api/student/reports/{id}/feedback`', '有用 / 没用'],
    ['`POST /api/teacher/reports/generate`', '按班批量生成（异步任务，返回 taskId）'],
    ['`GET /api/teacher/reports/overview`', '本班报告摘要：最低分项 TopN、生成成功率、成本']
  ], [30, 70]);
h2('4.7 验收指标');
table('报告验收',
  ['指标', '目标值', '怎么测'],
  [
    ['数字一致率', '100%', '自动回验脚本'],
    ['越权表述', '0 处', '词表扫描 + 人工抽查 20 份'],
    ['覆盖面', '≥ 90% 在读学生每 4 周至少 1 份', '按 `ai_report` 统计'],
    ['可读性', '≥ 80% 反馈"有用"', '`ai_report_feedback`'],
    ['单份成本', '≤ 0.01 元', '`ai_usage`'],
    ['批量耗时', '45 人班级 ≤ 3 分钟', '异步任务耗时']
  ], [20, 34, 46]);

/* ==================== 5 Dify 选型 ==================== */
h1('5 能力三：Agent 选型 —— 推荐 Dify 自托管');
h2('5.1 结论先说');
p('**推荐 Dify（自托管、本地 Docker Compose），版本固定 1.18.x；Spring Boot 只做业务网关与治理，不写编排。** 三条工作流（出题 / 报告 / 问答）在 Dify 里画，提示词改完即时生效；模型走 Dify 的"OpenAI-API-compatible"供应商接到 DashScope，Key 只在 Dify 里，不进代码库。');
table('候选方案对比（面向本项目：Spring Boot 4 + 单体 + 校园内网 + 本地 Docker）',
  ['方案', '优点', '缺点', '结论'],
  [
    ['**Dify 自托管**', '可视化工作流、内置知识库与 RAG 引用、Agent 与工具节点、支持 OpenAI 兼容模型、纯 Docker 部署、DSL 可导出进 Git', '多一套容器（约 8 个）；内存占用 4 到 8 GiB；升级要跟社区节奏', '**主线**'],
    ['Coze / 扣子', '上手快、插件多', '云端，数据出校；内网不可用', '不采用'],
    ['n8n', '自动化编排强、自托管成熟', '不擅长 LLM 与 RAG（无知识库、无引用、无 rerank）', '不采用（可作辅助自动化）'],
    ['Spring AI 2.0.2（上一版主线）', '全在 Java 里，零额外服务，离线友好', '编排靠代码，改提示词要发版；RAG 要自己搭检索与切块；几乎没有可视化调试', '改为**备选**（若不允许引入 Dify）'],
    ['LangChain4j 1.22.0', 'Java 生态成熟', '同上，且需自行验证与 Boot 4 适配', '不采用'],
    ['百炼"应用"（v1.0 方案）', '零代码、知识库成熟', '平台侧配置不可版本化；知识库与代码不同步；演示受外部服务影响', '不采用（Key 仍可作备用通道）']
  ], [18, 30, 32, 20]);
h2('5.2 三条应用与职责边界');
table('Dify 里的应用',
  ['应用', '类型', '输入 / 输出', '谁在用'],
  [
    ['出题工作流', 'Workflow', '课件片段 + 题型数量难度 → 题目 JSON', '教师端「AI 出题」'],
    ['报告工作流', 'Workflow', 'FactPack JSON → 四段正文 + 动作', '学生端报告、教师端班级摘要'],
    ['课程问答', 'Chatflow + 知识库', '学生提问 → 答案 + 引用 / 拒答', '学生端「课程答疑」'],
    ['（可选）批改辅助', 'Workflow', '参考答案 + 学生答案 + rubric → 分数建议 + 评语', '教师端批改弹窗'],
    ['（可选）学情问答', 'Agent / Workflow', '自然语言问题 → 调 `/api/ai/tools/*` → 带数据的回答', '教师端「问学情」']
  ], [18, 16, 38, 28]);
h2('5.3 怎么和 Spring Boot 接（推荐后端代理）');
table('三种集成方式',
  ['方式', '做法', '问题', '结论'],
  [
    ['**后端代理（推荐）**', '前端只调 v2.0 的 `/api/ai/*`，后端转 Dify `/v1/*`，签名与 Key 都在后端', '多一跳；流式要自己转发', '**采用**：权限、审计、脱敏、限额都在自己手里'],
    ['前端直连 Dify', '浏览器直接用 App API Key 调 Dify', 'Key 暴露、CORS、学生能绕过权限、样式不可控', '不采用'],
    ['iframe / Widget 嵌入', '把 Dify WebApp 或 widget 塞进页面', '登录态不共享、样式割裂、暴露 Dify 地址', '仅内测演示可用']
  ], [22, 34, 26, 18]);
p('一次出题的时序：前端 `POST /api/teacher/ai/questions/generate` → 后端写 `ai_run`（PENDING）→ 异步调 Dify `POST /v1/workflows/run`（`response_mode=blocking`，`user` 用"教师ID-任务ID"）→ 拿到输出 → Java 侧过一遍校验 → 落 `ai_question_draft` → 前端轮询 `GET /api/teacher/ai/tasks/{id}` 逐题渲染。');
note('流式可以后续再加：Dify 返回 SSE，后端用 Spring 的 SseEmitter 转发即可，前端不用换协议。第一版建议先做轮询，稳定优先。');
h2('5.4 模型怎么接');
table('Dify 侧配置（一次配好，全局复用）',
  ['配置项', '值', '说明'],
  [
    ['供应商类型', 'OpenAI-API-compatible', 'Dify 里"添加模型供应商"选这个'],
    ['Base URL', '`https://dashscope.aliyuncs.com/compatible-mode/v1`', '与 v1.0 兼容模式地址一致'],
    ['API Key', 'v1.0 那把（**已实测有效**）或新建', '只填在 Dify 里，不写进 `application.properties`'],
    ['模型', '出题 / 批改用 qwen-max；报告与分类用 qwen-plus；去重用 text-embedding 系列', '按场景分工控成本'],
    ['温度', '出题 0.3、报告 0.5', '工作流内可覆盖'],
    ['超时 / 重试', '60 秒 / 2 次', '与后端超时对齐']
  ], [20, 44, 36]);
note('这样做的额外好处：v1.0 遗留的 bailian-api-key 只有一个落点（Dify 的供应商配置），不再散落在代码与配置文件里；换模型只改 Dify，不用发版。');
h2('5.5 知识库与引用怎么做');
ul([
  '每个**课程**建一个 dataset（对应 `course`），文档按"课件 / 导学 / 讲义"分标签；跨班共享，符合"资料库是课程组共享"的既有设定。',
  '文档来源是后端用 POI 抽出的 markdown（见 3.2），**每块带页码**，所以回答能给出"依据：第 3 章 第 12 页"的引用。',
  '检索参数第一版：分段 500 字 / 重叠 50 / TopK 4 / 相似度阈值 0.3；开了 rerank 再往上调。',
  '**拒答**：知识库无命中时，用固定话术"没有检索到依据，建议问任课老师"，不让模型自由发挥。',
  '先用 Dify 自带的"召回测试"页把 20 个真实问题的命中率调好，再写代码。'
]);
h2('5.6 版本化：把 Dify 拉回可复现');
p('"平台配置不可版本化"是 Dify 最大的批评，但可以治：**应用 DSL 支持导出 / 导入**。约定如下：');
ul([
  '`v2.0/ai/dify/` 目录存三条工作流的 DSL（question-gen.yml、report.yml、course-qa.yml），与代码一起提交。',
  '每次改工作流 → 导出 DSL → 提交 → 在 `ai_prompt_template` 记 `dify_app_id` 与 `workflow_version`。',
  '部署到新机器时 `docker compose up -d` 后用 DSL 一键导入，环境即可重建。',
  '模型供应商配置用环境变量加文档记录，Key 不入库、不入 Git。'
]);

/* ==================== 6 Docker 部署 ==================== */
h1('6 本地 Docker 部署（与现有栈不冲突）');
h2('6.1 端口与容器规划');
p('本机现状（实测）：MySQL 占 3306；80 / 443 / 8080 / 5173 空闲。规划如下 —— **Dify 全家桶只对外暴露两个端口，且都避开 80 与 443**：');
table('端口分配表',
  ['宿主端口', '容器 / 服务', '占用方', '说明'],
  [
    ['3306', '宿主 MySQL（非容器）', 'v2.0 数据库', '**保持不动**；Dify 的数据库是容器内 Postgres，不发布端口'],
    ['8080', 'Spring Boot', 'v2.0 后端', '保持不动'],
    ['5173', 'Vite dev 或 Nginx 静态', 'v2.0 前端', '保持不动'],
    ['**8090**', 'dify-nginx（HTTP）', 'Dify', '由 `EXPOSE_NGINX_PORT=8090` 指定，**故意避开 80**'],
    ['**8443**', 'dify-nginx（HTTPS）', 'Dify', '不需要 HTTPS 时可在 override 里删掉这条'],
    ['15003', 'plugin_daemon（调试）', 'Dify', '仅调试插件用，不需要就不发布'],
    ['内部端口 5001 / 5002 / 3000 / 5432 / 6379 / 8080(weaviate) / 8194(sandbox)', 'api / plugin_daemon / web / db_postgres / redis / weaviate / sandbox', 'Dify 内部网络', '**均不发布到宿主**，与 8080 的 Spring 互不影响（实测现版本 weaviate 只在 `weaviate` profile 下且不映射宿主端口）']
  ], [16, 26, 20, 38]);
h2('6.2 compose 覆盖片段（不改官方文件）');
p('官方 `docker/docker-compose.yaml` 不要直接改，用 override 叠加，升级时不会打架：');
ul([
  '`docker/.env`：`EXPOSE_NGINX_PORT=8090`、`EXPOSE_NGINX_SSL_PORT=8443`、`FILES_URL=http://localhost:8090`、`SECRET_KEY=<随机 64 位>`、`PLUGIN_DAEMON_KEY=<随机>`。',
  '`docker/docker-compose.override.yaml`：覆盖 nginx 的 ports；给 api / worker 加 `extra_hosts: host.docker.internal:host-gateway`（便于 Dify 反向调我们的 `/api/ai/tools/*`）；plugin_daemon 的 5003 改成 15003。',
  '启动：`docker compose --profile postgresql up -d`。数据库用默认 Postgres，**不要**把 Dify 指向宿主 3306 那套 MySQL，避免抢实例、抢字符集。',
  '验证：浏览器开 `http://localhost:8090` 进初始化页 → 建管理员 → 配模型供应商 → 导入 DSL。'
]);
h2('6.3 资源与运行环境');
table('资源需求（本机实测 15.7 GiB 内存，够用）',
  ['项目', '建议', '备注'],
  [
    ['Docker Desktop 内存', '8 GiB（最低 4 GiB）', '官方门槛 CPU ≥2 核 / RAM ≥4 GiB；WSL2 后端建议 8 GiB'],
    ['磁盘', '预留 15 GB', '镜像约 6 到 8 GB + volumes + 知识库文件'],
    ['CPU', '4 核以上', '本地不跑模型推理，全部走 DashScope API'],
    ['网络', '能访问 dashscope 与 Docker Hub', '镜像可先在有网环境 pull，再 save 到内网机器'],
    ['开机自启', '`restart: always`（官方默认）', '演示前确认 `docker ps` 里 8 个容器都 Up']
  ], [22, 30, 48]);
h2('6.4 启动、体检、备份、升级');
ol([
  '**启动顺序**：Docker Desktop → `docker compose up -d` → 等容器 Healthy（1 到 2 分钟）→ 后端 `java -jar` → 前端。',
  '**体检**：`docker compose ps` 全 Up + 打开 `http://localhost:8090` + 调后端新增的 `/api/ai/health`（返回 Dify 可达性）。',
  '**备份三件套**：`docker/volumes/` 整目录、Postgres 的 pg_dump、三条工作流 DSL 导出。',
  '**升级**：固定 tag（如 1.18.x，**不要用 latest 或 main**）→ 升级前导出 DSL 与数据库备份 → 拉新 tag → 迁移 → 冒烟。',
  '**回滚**：镜像 tag 回退 + 数据库备份还原 + DSL 重新导入。'
]);
h2('6.5 离线 / 内网部署镜像清单');
table('需要搬运的镜像（docker save / load）',
  ['镜像', '用途'],
  [
    ['`langgenius/dify-api:<tag>`', '后端 API 与 worker'],
    ['`langgenius/dify-web:<tag>`', '前端控制台'],
    ['`nginx:<ver>`', '反向代理（Dify 侧）'],
    ['`postgres:<ver>`', 'Dify 自己的数据库'],
    ['`redis:<ver>`', '缓存与队列'],
    ['`semitechnologies/weaviate:<ver>`', '向量库（用默认 weaviate 时）'],
    ['`langgenius/dify-sandbox:<ver>`', '代码节点沙箱'],
    ['`langgenius/dify-plugin-daemon:<ver>`', '插件守护进程'],
    ['（可选）unstructured 相关镜像', '**不开 ETL=Unstructured 就不需要**，这也是推荐"后端抽文本"的原因之一']
  ], [44, 56]);
h2('6.6 分工界面：谁存什么');
table('数据归属',
  ['数据', '存放位置', '说明'],
  [
    ['学生 / 课程 / 成绩 / 题库 / 预警', '宿主 MySQL 3306（v2.0）', '唯一权威来源；Dify 不直连数据库'],
    ['AI 草稿、报告、运行与计费', '宿主 MySQL（`ai_*` 表）', '在业务库里，便于 join 与审计'],
    ['课件原文与抽取文本', '业务表 `resource_file` + 磁盘；文本副本进 Dify 知识库', '两边都留一份，知识库可重建'],
    ['Dify 自身（应用、会话、索引）', 'Dify 的 Postgres + volumes', '按 6.4 备份'],
    ['工作流定义', '`v2.0/ai/dify/*.yml`（Git）', '与代码同版本管理']
  ], [26, 34, 40]);

/* ==================== 7 其余建议 ==================== */
h1('7 其余建议（按性价比排序）');
p('P0 = 不做则后面落不了地；P1 = 性价比最高；P2 = 有余力再做。');
h2('7.1 P0：先把 Docker 底座与模型通道跑通（2 人日）');
p('顺序：Docker Desktop 内存调到 8 GiB → 起 Dify（8090）→ 配 DashScope 供应商 → 建一个"回声"工作流验证 workflows/run 能通 → 后端加 `/api/ai/health`。**这一步不通，后面的工作流都是纸面。**');
h2('7.2 P0：指标与评测集先定（1 人日）');
p('把 3.6 与 4.7 的指标抄成一张验收表，再准备 30 条 golden 用例（给定输入 → 期望要点），复用 v1.0 的 `agent_golden_cases.json` 思路。论文里唯一能写"实验"的就是这两样。');
h2('7.3 P1：智能批改辅助（性价比最高）');
p('259 道主观题、810 条手工分是最直接的痛点。Dify 工作流：参考答案 + rubric + 学生答案 → "分数建议 + 评语草稿"，老师一键采纳或改分。**比出题更容易被认可**，因为它直接省时间。');
h2('7.4 P1：AI 预警解释卡（与主线最贴）');
p('学生看到的预警现在是固定话术。改成：触发原因（缺勤 5 次 / 允许 4 次）+ 距下一档差多少分 + 三条补救动作；数字全部来自 `risk_state` 的 data_quality_json，模型只做表述。1 到 2 人日，答辩加分最大。');
h2('7.5 P1：教师"自然语言查学情"');
p('把 v1.0 的 9 个工具改造成 `/api/ai/tools/*`，Dify 用 HTTP 请求节点或 Agent 工具节点调用（`host.docker.internal:8080`），**Dify 不碰数据库**。这是"Agent 而不只是聊天机器人"的最好证据。');
h2('7.6 P1：课程知识库答疑');
p('语料来自资料库与导学（后端抽文本上传），学生问"这题为什么选 B"，回答带引用（哪份课件第几页），无依据就拒答。把"资料库"从存储变成服务。');
h2('7.7 P2：班级学情周报（辅导员 / 教务）');
p('按班聚合：本周新增预警、最低分项、出勤下滑 5 人、需要谈话名单。辅导员要"名单与理由"，不要图表。一个班一次调用，成本极低。');
h2('7.8 P2：主观题相似度聚类');
p('同一道简答题的答案做 embedding 聚类，标出"高度相似组"交给老师判断。**只提示，不自动判抄袭。**');
h2('7.9 建议不做的（避坑）');
ul([
  '**不要引入知识点本体**：本节全篇都在证明"不加也能做"，加了只会拖慢进度、增加维护。',
  '**不要让 AI 改判定数值**：一旦模型能改档位，第二阶段"可解释、可复现"的卖点就没了。',
  '**不要为 RAG 再装一个向量库**：Dify 自带 weaviate（或 qdrant profile），别再起 Milvus / Chroma。',
  '**不要把 Dify 指向业务库 3306**：它的迁移脚本会在库里建几十张表，风险与收益不成比例。',
  '**不要用 latest 或 main 镜像**：演示前夜自动升级是事故的经典开场。',
  '**不要做"AI 辅导员谈心"**：心理相关只提示"建议关注"，不给结论。'
]);

/* ==================== 8 里程碑 ==================== */
h1('8 里程碑与工作量');
p('按"一人全职、每天 6 小时有效开发"估算，**约 16.5 人日**（比含知识点的版本少 4.5 人日，主要省在不用建本体、不用挂 274 道题）。');
table('第三阶段里程碑（Dify 版）',
  ['里程碑', '内容', '产出', '人日', '验收'],
  [
    ['M1 底座', 'Docker 起 Dify（8090）+ DashScope 供应商 + 回声工作流 + 后端 `/api/ai/health` + `ai_run` / `ai_run_step` / `ai_usage` 表', '双栈可同时运行、AI 通道可探活', '2', '`docker ps` 全 Up；后端跑通一次 workflows/run'],
    ['M2 出题', 'POI 抽文本 → markdown → 上传知识库 → 出题工作流 → 五道闸门 → 审题页 → 采纳入卷', '`ai_question_draft` 全流程 + 教师端页面', '4.5', '3.6 的七项指标达标'],
    ['M3 报告', 'FactPack 生成 → 规则归因 → 报告工作流 → 数字回验 → 学生端页面 + 反馈', '`ai_report` 全流程 + 学生端与教师端页面', '4', '4.7 的六项指标达标'],
    ['M4 问答', '课程知识库（按课程建 dataset）+ Chatflow + 引用与拒答 + 学生端入口', '问答闭环', '2', '20 个真实问题引用正确率 ≥ 85%，超范围能拒答'],
    ['M5 治理', 'AI 开关、日限额、脱敏、成本看板、运行历史页', '治理层', '2', '关掉开关全站不报错；超额提示正确'],
    ['M6 质量与交付', 'golden 集扩到 30 条 + 评测脚本 + 部署与备份文档 + DSL 进 Git + 演示脚本', '评测报告 + 部署文档', '2', '换一台机器能按文档重建']
  ], [14, 40, 20, 8, 18]);
note('若时间只够到 M3（10.5 人日）：出题与报告两条能力先上，问答与治理延后。答辩提问最集中的是"出题准不准、报告凭什么这么说"，而不是"有没有 RAG"。');

/* ==================== 9 演示脚本 ==================== */
h1('9 演示脚本（5 分钟，接在第二阶段之后）');
table('加演路线',
  ['时间', '动作', '要讲的一句话'],
  [
    ['0:00–0:40', '教师端 → 计基 01 班 → 课件 → 选一份 PPTX → AI 出题（5 单选 + 2 判断）', '老师原来出这套题要 20 分钟，现在 30 秒出草稿，只审不改'],
    ['0:40–1:30', '审题弹窗：看"依据：第 12 页"、单题重生成、改一道、批量通过 → 加入试卷', '每道题都能追到课件的具体一页，这是可解释的生成'],
    ['1:30–2:20', '学生端 → 20250001 → 学习评价报告：结论 + 分项 + 正文 + 三个动作', '报告里的每个数字都在系统里，模型只负责说人话'],
    ['2:20–3:00', '点「重做这几题」直接跳到练习；点「约答疑」跳到预约', '报告的价值是动作，不是文字'],
    ['3:00–3:40', '学生端 → 课程答疑：问"第 6 周那道链表题为什么错"，看到引用（课件第 12 页）', '答不上来会明确拒答，不编'],
    ['3:40–4:20', '教师端 → 问学情："计基 01 班谁最危险" → 看到工具调用轨迹', '这不是聊天机器人，是能自己查库的智能体，每个数字可追溯'],
    ['4:20–4:50', '地址栏展示 localhost:8090（Dify 控制台）与 localhost:5173（业务系统）并存', '两套系统各司其职：Dify 生成，业务系统存权威数据'],
    ['4:50–5:00', '关掉 AI 开关，刷新页面：AI 入口消失、原有功能正常', 'AI 是可插拔能力，不是单点依赖']
  ], [12, 54, 34]);

/* ==================== 10 风险 ==================== */
h1('10 风险登记表');
table('主要风险与应对',
  ['风险', '影响', '概率', '应对'],
  [
    ['Docker Desktop 内存不足或 WSL2 卡顿', 'Dify 起不来或很慢', '中', '把 Docker VM 调到 8 GiB；演示前重启 Docker Desktop 并预热'],
    ['8090 / 8443 被占用', '起不了容器', '低', '先用 netstat 查；override 里换端口，`.env` 只改 `EXPOSE_*`'],
    ['镜像拉不动（网络）', '部署中断', '中', '提前在有网机器 pull 并 save；或换镜像加速器'],
    ['PPTX 抽不出文本（图片型）', '出题不可用', '高', '检测文本密度并提示改用可复制文本或粘贴；不承诺 OCR'],
    ['模型额度耗尽或 dashscope 不可达', '生成失败', '中', '演示前查余额；`ai.enabled=false` 整体降级；预生成一批结果缓存'],
    ['工作流改坏或升级不兼容', '功能异常', '中', 'DSL 进 Git + 升级前备份；固定镜像 tag'],
    ['生成题目质量差、老师不用', '功能形同虚设', '中', '五道闸门 + 依据片段 + 单题重生成；先 1 门课试点'],
    ['报告出现错误数字', '信任崩塌', '中', '数字白名单回验 + 模板兜底 + 抽查'],
    ['Dify 与业务库混用', '数据污染', '低', 'Dify 只用容器内 Postgres，绝不指向 3306'],
    ['隐私（成绩 / 心理问卷）外发', '合规风险', '中', '脱敏 + 最小化 + 审计 + 不训练承诺；心理数据不进模型'],
    ['成本失控', '预算超支', '低', '按用户与场景限额 + 熔断 + 成本看板']
  ], [26, 20, 8, 46]);

/* ==================== 11 附录 ==================== */
h1('11 附录');
h2('11.1 后端接口草案');
table('新增接口',
  ['方法与路径', '角色', '说明'],
  [
    ['`POST /api/teacher/ai/questions/generate`', '教师', '提交生成任务，返回 taskId'],
    ['`GET /api/teacher/ai/tasks/{taskId}`', '教师', '任务进度与逐题结果（轮询）'],
    ['`POST /api/teacher/ai/questions/{draftId}/review`', '教师', '通过 / 改后通过 / 弃用（可批量）'],
    ['`POST /api/teacher/ai/questions/{draftId}/adopt`', '教师', '采纳入卷（新建 DRAFT 卷或追加分组）'],
    ['`POST /api/teacher/ai/reports/generate`', '教师 / 教务', '按班批量生成报告'],
    ['`GET /api/student/reports`、`/{id}`、`/{id}/feedback`', '学生', '报告列表 / 详情 / 反馈'],
    ['`POST /api/teacher/ai/ask`', '教师', '自然语言学情（转 Dify，返回答案 + 工具轨迹）'],
    ['`POST /api/student/ai/qa`', '学生', '课程问答（返回答案 + 引用；无依据拒答）'],
    ['`GET /api/admin/ai/usage`', '教务', '成本与调用统计'],
    ['`GET /api/ai/health`', '内部', 'Dify 可达性与模型可用性探活']
  ], [44, 14, 42]);
h2('11.2 与 Dify 对接的关键参数');
table('调用清单',
  ['Dify 接口', '用途', '关键参数'],
  [
    ['`POST /v1/workflows/run`', '跑出题 / 报告工作流', 'inputs（结构化）、response_mode=blocking、user=教师ID-任务ID'],
    ['`POST /v1/chat-messages`', '课程问答', 'query、conversation_id、user、inputs'],
    ['`POST /v1/files/upload`', '上传课件或文本', 'multipart，user'],
    ['`POST /v1/datasets/{id}/document/create-by-text`', '文本入库', 'name、text、process_rule（分段 500 / 重叠 50）'],
    ['`POST /v1/datasets/{id}/retrieve`', '检索测试或自建引用', 'query、retrieval_model'],
    ['鉴权', '所有调用', 'Authorization: Bearer <App API Key>（应用级）或 <Dataset API Key>（知识库级）']
  ], [40, 22, 38]);
h2('11.3 出题 Prompt 骨架');
p('**System**：你是高校课程命题助手，服务对象是任课教师。只依据给定材料命题，不引入材料之外的知识，不编造公式或代码细节。');
ul([
  '【材料片段】（来自《课程名》第 N 周课件，第 X 到 Y 页）：……',
  '【已有分组名】（沿用统一命名，避免同义分裂）：线性表 / 链表操作 / 栈与队列 ……',
  '【题型】单选；【数量】2；【难度】medium；【分值】2',
  '【输出】严格 JSON 数组，每项含 stem / options / answer / analysis / group_name / source_pages；题干不得出现"根据材料"等指代词。'
]);
h2('11.4 参考资料');
ul([
  'Dify 官方部署文档（硬件门槛与 Docker Compose 步骤）：https://docs.dify.ai/en/self-host/deploy/quick-start/docker-compose',
  'Dify 环境变量说明：https://docs.dify.ai/en/self-host/deploy/configuration/environments',
  'Dify 源码 api/constants/__init__.py（决定支持的扩展名，pptx 仅在 ETL_TYPE=Unstructured 时可用）：https://github.com/langgenius/dify/blob/main/api/constants/__init__.py',
  'Dify 官方 compose（只有 nginx 与 plugin_daemon 发布端口）：https://github.com/langgenius/dify/blob/main/docker/docker-compose.yaml',
  'Dify 镜像 tag 列表（当前 1.18.x）：https://hub.docker.com/r/langgenius/dify-api/tags',
  '阿里云百炼模型价格（以控制台为准）：https://www.alibabacloud.com/help/zh/model-studio/model-pricing'
]);
h2('11.5 需要你确认的 6 件事');
ol([
  '**Dify 版本**：固定 1.18.x 可以吗？（若要更稳，选上一个次版本的最新 hotfix）',
  '**Dify 数据库**：用容器内 Postgres（推荐），还是指定 MySQL 容器？**不建议指向现有 3306**。',
  '**端口**：8090 / 8443 是否可以？（若还要给别的服务留 80 / 443，我再换）',
  '**出题范围**：只考本节课，还是允许指定"第 3 到 5 章"（跨课件检索）？',
  '**报告可见性**：只给学生本人，还是同时给任课教师与辅导员？',
  '**心理问卷数据**是否进 AI 分析（我的建议：不进，只做规则提示）。'
]);

const meta = {
  title: '学情预警系统 v2.0',
  subtitle: '第三阶段 · AI 智能能力规划（修订稿 · Dify 自托管）',
  sub2: 'AI 出题 · 学习评价报告 · Dify Agent 与 RAG · 本地 Docker 部署',
  tip: '本稿只做方案讨论，不含代码改动；已按要求取消"知识点"设计，Agent 推荐 Dify 自托管并给出零端口冲突的部署方案',
  info: [
    ['文档名称', '学情预警系统 v2.0 · 第三阶段 AI 智能能力规划（修订稿 · Dify 自托管）'],
    ['本版要点', '① 取消知识点（零表结构变更）；② Agent 改推 Dify 自托管（本地 Docker）；③ 出题 / 报告 / 问答三条工作流；④ 端口、镜像、备份、离线与版本化方案'],
    ['不含', '不修改现有代码与数据库；不改动第二阶段的判定口径与预警状态机'],
    ['依据', '演示库实测（5 门课 / 12 班 / 540 学生 / 127 卷 / 274 题 / 5580 份提交 / 11160 条作答）、v1.0 源码盘点、Dify 源码与官方文档、本机 Docker 与端口实测'],
    ['规模估算', '6 个里程碑、约 16.5 人日（一人全职约 3 周）'],
    ['编写日期', '2026-12']
  ]
};

const out = path.join(__dirname, 'ai_stage3.json');
fs.writeFileSync(out, JSON.stringify({ meta, blocks: B }, null, 1), 'utf8');
const stat = { h: 0, p: 0, tbl: 0, li: 0 };
B.forEach((b) => {
  if (b.t[0] === 'h') stat.h++;
  else if (b.t === 'p' || b.t === 'note') stat.p++;
  else if (b.t === 'table') stat.tbl++;
  else stat.li += b.x.length;
});
console.log('WROTE ' + out);
console.log(JSON.stringify(stat));
